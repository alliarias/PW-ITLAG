const techniques = [
  {name:"Técnica por completar", description:"Espacio reservado para agregar información oficial.", image:"IMAGEN"},
  {name:"Técnica por completar", description:"Espacio reservado para agregar información oficial.", image:"IMAGEN"},
  {name:"Técnica por completar", description:"Espacio reservado para agregar información oficial.", image:"IMAGEN"}
];

const techniqueCards = document.getElementById("techniqueCards");
const modal = document.getElementById("modal");
const modalContent = document.getElementById("modalContent");

function renderTechniques(){
  techniqueCards.innerHTML = techniques.map((t,i)=>`
    <article class="tech-card">
      <div class="tech-image">${t.image}</div>
      <h3>${t.name}</h3>
      <p>${t.description}</p>
      <button class="btn secondary" onclick="showTechnique(${i})">Conocer</button>
    </article>`).join("");
}
function showTechnique(i){
  const t=techniques[i];
  modalContent.innerHTML=`<span class="eyebrow">INFORMACIÓN DE LA TÉCNICA</span><h2>${t.name}</h2><p><b>¿De qué trata?</b><br>Por completar con información oficial.</p><p><b>¿Qué se aprende?</b><br>Por completar con información oficial.</p><p><b>¿Qué habilidades se desarrollan?</b><br>Por completar con información oficial.</p>`;
  modal.classList.remove("hidden");
}
document.getElementById("closeModal").onclick=()=>modal.classList.add("hidden");
modal.addEventListener("click",e=>{if(e.target===modal)modal.classList.add("hidden")});
renderTechniques();

document.querySelectorAll(".week-title").forEach(btn=>btn.addEventListener("click",()=>{
  btn.parentElement.classList.toggle("active");
}));

const questions=[
  {q:"¿Qué actividad te interesa más?",a:["Tecnología","Trabajo práctico","Creatividad","Organización","Investigación"]},
  {q:"¿Qué tipo de tarea disfrutas más?",a:["Resolver problemas con tecnología","Construir o hacer cosas","Crear ideas y diseños","Planear y ordenar","Buscar y analizar información"]},
  {q:"¿En qué actividad te gustaría mejorar?",a:["Herramientas digitales","Habilidades prácticas","Expresión creativa","Organización de proyectos","Investigación y análisis"]},
  {q:"¿Qué te gustaría usar más en un proyecto?",a:["Computadores y tecnología","Materiales y herramientas","Diseño e ideas","Planes y procesos","Información y fuentes"]}
];
let current=0, selected=null, scores=[0,0,0,0,0];
const questionText=document.getElementById("questionText"), answers=document.getElementById("answers"), nextBtn=document.getElementById("nextBtn"), progress=document.getElementById("progressBar"), questionNumber=document.getElementById("questionNumber");
const areaNames=["Tecnología","Trabajo práctico","Creatividad","Organización","Investigación"];

function loadQuestion(){
  selected=null; nextBtn.disabled=true;
  const item=questions[current];
  questionNumber.textContent=`Pregunta ${current+1} de ${questions.length}`;
  questionText.textContent=item.q;
  progress.style.width=`${(current/questions.length)*100}%`;
  answers.innerHTML=item.a.map((x,i)=>`<button class="answer" data-index="${i}">${x}</button>`).join("");
  answers.querySelectorAll(".answer").forEach(b=>b.addEventListener("click",()=>{
    answers.querySelectorAll(".answer").forEach(x=>x.classList.remove("selected"));
    b.classList.add("selected"); selected=Number(b.dataset.index); nextBtn.disabled=false;
  }));
}
nextBtn.addEventListener("click",()=>{
  scores[selected]++;
  current++;
  if(current<questions.length){loadQuestion()}else{showResult()}
});
function showResult(){
  document.querySelector(".quiz-box").classList.add("hidden");
  document.getElementById("resultBox").classList.remove("hidden");
  progress.style.width="100%";
  const max=Math.max(...scores), winner=scores.indexOf(max);
  document.getElementById("resultArea").textContent=areaNames[winner];
}
document.getElementById("restartBtn").addEventListener("click",()=>{
  current=0;scores=[0,0,0,0,0];
  document.getElementById("resultBox").classList.add("hidden");
  document.querySelector(".quiz-box").classList.remove("hidden");
  loadQuestion();
});
loadQuestion();

const toggle=document.getElementById("menuToggle"), nav=document.getElementById("mainNav");
toggle.addEventListener("click",()=>nav.classList.toggle("open"));
nav.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));

document.querySelectorAll("a[href^='#']").forEach(a=>a.addEventListener("click",()=>{
  const target=document.querySelector(a.getAttribute("href"));
  if(target) target.scrollIntoView({behavior:"smooth"});
}));

document.getElementById("officialBtn").addEventListener("click",()=>{
  document.getElementById("officialMsg").textContent="Agrega aquí el enlace oficial verificado del Instituto cuando el equipo lo tenga.";
});
