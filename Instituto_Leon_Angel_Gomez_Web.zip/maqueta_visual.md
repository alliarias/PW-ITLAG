# MAQUETA VISUAL / WIREFRAME
## Instituto Técnico León Ángel Gómez — Conoce, elige y aprende

### Pantalla 1 — Inicio
┌────────────────────────────────────────────────────────────┐
│ LEAG   INICIO  INSTITUTO  TÉCNICAS  INTERESES  PLAN ...   │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  INSTITUTO TÉCNICO                                         │
│  LEÓN ÁNGEL GÓMEZ                                          │
│  CONOCE, ELIGE Y APRENDE                                   │
│  Conoce nuestras técnicas y descubre oportunidades.        │
│                    [ EXPLORAR TÉCNICAS ]                   │
│                                  ┌───────────────────────┐ │
│                                  │ 🎓                    │ │
│                                  │ Tu camino empieza    │ │
│                                  │ con información      │ │
│                                  └───────────────────────┘ │
└────────────────────────────────────────────────────────────┘

### Pantalla 2 — Instituto
┌─────────────────────────────┬──────────────────────────────┐
│                             │ CONOCE EL INSTITUTO           │
│       [ IMAGEN ]            │ Información general           │
│                             │ del Instituto                 │
│                             │ [ CONOCER MÁS ]               │
└─────────────────────────────┴──────────────────────────────┘

### Pantalla 3 — Técnicas
┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐
│     IMAGEN       │ │     IMAGEN       │ │     IMAGEN       │
│                  │ │                  │ │                  │
│ TÉCNICA POR      │ │ TÉCNICA POR      │ │ TÉCNICA POR      │
│ COMPLETAR        │ │ COMPLETAR        │ │ COMPLETAR        │
│ [ CONOCER ]      │ │ [ CONOCER ]      │ │ [ CONOCER ]      │
└──────────────────┘ └──────────────────┘ └──────────────────┘
NOTA: NO SE INVENTAN NOMBRES DE TÉCNICAS.

### Pantalla 4 — Detalle de técnica
┌────────────────────────────────────────────────────────────┐
│                NOMBRE DE LA TÉCNICA                         │
├──────────────────────┬─────────────────────────────────────┤
│ [ IMAGEN ]           │ ¿DE QUÉ TRATA?                      │
│                      │ ¿QUÉ SE APRENDE?                    │
│                      │ ¿QUÉ HABILIDADES SE DESARROLLAN?    │
└──────────────────────┴─────────────────────────────────────┘
                         [ VOLVER ]

### Pantalla 5 — Descubre tus intereses
┌────────────────────────────────────────────────────────────┐
│                 DESCUBRE TUS INTERESES                     │
│ ¿QUÉ ACTIVIDAD TE INTERESA MÁS?                             │
│ ○ Tecnología                                               │
│ ○ Trabajo práctico                                         │
│ ○ Creatividad                                               │
│ ○ Organización                                              │
│ ○ Investigación                                             │
│                         [ SIGUIENTE ]                       │
└────────────────────────────────────────────────────────────┘

### Resultado
┌────────────────────────────────────────────────────────────┐
│                     TU RESULTADO                           │
│ AREA DE MAYOR INTERÉS: TECNOLOGÍA                          │
│ Resultado únicamente orientativo.                          │
│       [ REPETIR ]          [ VER TÉCNICAS ]                │
└────────────────────────────────────────────────────────────┘

### Pantalla 6 — Plan de mejoramiento
SEMANA 1 ───── SEMANA 2 ───── SEMANA 3 ───── SEMANA 4
INVESTIGACIÓN      DISEÑO       PROGRAMACIÓN      PRUEBAS
     ✓               ✓               ○               ○

Cada semana se abre para mostrar objetivo, actividades y resultado.

### Pantalla 7 — Equipo
[01 INVESTIGACIÓN] [02 DISEÑO + HTML/CSS] [03 JAVASCRIPT]
                    ↓
          PRODUCTO FINAL DEL EQUIPO

### Pantalla 8 — Contacto
┌────────────────────────────────────────────────────────────┐
│ CONTACTO                                                   │
│ Instituto Técnico León Ángel Gómez                         │
│ Dirección: Por agregar                                     │
│ Teléfono: Por agregar                                      │
│ Correo: Por agregar                                        │
│ [ CONSULTAR INFORMACIÓN OFICIAL ]                          │
└────────────────────────────────────────────────────────────┘
